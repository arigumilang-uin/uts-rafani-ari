package com.example.belajarbahasa.adapters;

public class LessonAdapter {
}
