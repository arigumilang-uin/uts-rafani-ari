package com.example.belajarbahasa.models;

public class Quiz {
}
