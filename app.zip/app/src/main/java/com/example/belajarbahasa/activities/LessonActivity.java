package com.example.belajarbahasa.activities;

import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.belajarbahasa.R;

public class LessonActivity extends AppCompatActivity {

    public static final String EXTRA_LESSON_TITLE = "lesson_title";
    public static final String EXTRA_LESSON_CONTENT = "lesson_content";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson);

        // Ambil data dari intent
        String title = getIntent().getStringExtra(EXTRA_LESSON_TITLE);
        String content = getIntent().getStringExtra(EXTRA_LESSON_CONTENT);

        // Bind ke layout
        TextView titleText = findViewById(R.id.lessonTitleTextView);
        TextView contentText = findViewById(R.id.lessonContentTextView);

        titleText.setText(title);
        contentText.setText(content);
    }
}
