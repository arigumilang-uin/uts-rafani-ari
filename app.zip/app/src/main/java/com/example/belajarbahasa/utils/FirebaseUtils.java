package com.example.belajarbahasa.utils;

public class FirebaseUtils {
}
