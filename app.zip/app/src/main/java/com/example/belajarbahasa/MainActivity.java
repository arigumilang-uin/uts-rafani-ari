package com.example.belajarbahasa;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.belajarbahasa.R;
import com.example.belajarbahasa.activities.DashboardActivity;
import com.example.belajarbahasa.activities.LoginActivity;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null) {
            // User sudah login, langsung ke dashboard
            startActivity(new Intent(com.example.belajarbahasa.MainActivity.this, DashboardActivity.class));
        } else {
            // Belum login, ke halaman login
            startActivity(new Intent(com.example.belajarbahasa.MainActivity.this, LoginActivity.class));
        }

        finish(); // Biar MainActivity nggak bisa di-back
    }
}
